**Membres présents :** Armored, Phanta, Frost, Ninjdai, Noe, Cholrac
**Date : 26 Mai 2024**
# Ordre du jour
- Définir organisation pour suite projet
- Intérêts des collaborateurs

# Statut actuel jeu
- Système de multi fonctionnel, cad nb illimité joueurs peuvent se co
- sys de compte sécurisé
- début implémentation bdd en sql
- sys de chat comprenant squad, guilde
- sys de chunk loader à revoir à long terme
- Créateur de perso tribal
# Mesures mises en vigueur
## Travail à effectuer
- Frost : 
	1. appels vocaux pour relecture lore actuel et continuer avec Cholrac
---
- Cholrac : 
	1. Game design du système de combat
	2. appels vocaux pour relecture lore actuel et continuer avec Frost
	3. Description de divers environnements de jeu à donner à Phanta
---
- Phanta :
	1. Ajouter assets pour créateur perso
	2. Animations de ces dits assets, 4 vues + walk
	3. Tilesets pour identité du jeu 32\*32 
	4. greyscale plus clairs
---
- Armored :
	1. Ajouter setting de luminosité pour la couleur des assets dans créateur de persos
---
- Noe :
	1. Créer persos pour agrémenter le lore
	2. apte à aider un peu partout
---
- Ninjdai :
	1. feur
