Durée : 2 semaines irl
caractérisation : définis par la [[saisons mērēliennes|saison mērēlienne]] et le [[cycles éthéréens|cycle éthéréen]] durant ce temps (voir tableaux de combinaisons)

| cycle éthéréen \ saison mērēlienne | printemps | été | automne | hiver |
| ---------------------------------- | --------- | --- | ------- | ----- |
| **nitescent**                      |           |     |         |       |
| ****                               |           |     |         |       |
| **kinéscent**                      |           |     |         |       |
| **némesis**                        |           |     |         |       |
