1. Légats : Gouverneurs de province sous le contrôle démon
2. La matière est au réel ce que l'éther est à l'imaginaire, à développer tout le propos.
3. Système de classes
4. Développer les esprits
5. peuple des oubliés
	- Ont pour caractéristique des cheveux colorés et hirsutes
	- ne jamais mourir 
	- Chaque mort les voit oublié de la mémoire des gens rencontrés, ils réapparaissent à un lieu précédemment visité
	- La plupart cherchent un moyen de briser la malédiction
6.  Floréclat, A season of growth and blossoming
7. Religion où les puissants utilisent la poudre de Lacrymète pour s'en mettre plein la gueule -> milice si t'as des bouts de comète car considérée comme relique.