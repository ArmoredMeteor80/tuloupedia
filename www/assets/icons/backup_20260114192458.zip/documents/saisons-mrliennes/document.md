# Printemps
durée : 7 semaines
description :

impact mapping :
impact Bestiaire :
impact ressource génération :

fêtes :



# Été 
durée : 6 semaines
# Automne 
durée : 7 semaines

# Hiver
durée : 6[[Müt|Müts]]