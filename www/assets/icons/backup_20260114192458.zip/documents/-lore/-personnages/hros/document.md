## Individu
- Nom, Prénom, Surnoms : 
- Date de naissance :
- Espèce/ethnie : [[Foïn]]
## Social 
- Famille :
- Amour : 
- Amis :
- Autres :
## Physique

## Objectif
- But :
- Motivations :
# Description

# Annexes
Backstory : Le personnage s'est suicidé en boucle pour tout oublier. Il a pour cela, écrit de se suicider en boucle, et dès lors qu'il se souvient de rien, arracher la page du livre pour qu'il ne se souvienne même pas qu'il s'est tué. Sur une page du livre, il est écrit le fonctionnement de celui-ci.
# Visuels
