# Infos
## Individu
- Dénominations : Crimith
- Lieu de naissance : à déterminer
- Espèce/ethnie : [[Démons]]
## Social 
- Famille : Amante de [[Roi Démon]], Mère de [[Délith]]
- Amis : à déterminer
- Autres : 
## Physique

## Objectif

# Description

# Annexes

# Visuels