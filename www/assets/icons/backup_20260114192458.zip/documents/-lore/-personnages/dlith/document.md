# Infos
## Individu
- Dénominations : Délith
- Lieu de naissance : à déterminer
- Espèce/ethnie : [[Démons]]
## Social 
- Famille : Fille de [[Roi Démon]] et de [[Délith]]
- Amis : à déterminer
- Autres : 
## Physique

## Objectif

# Description
De caractère assez rebelle, elle mène des recherches quant à son père.
# Annexes

# Visuels