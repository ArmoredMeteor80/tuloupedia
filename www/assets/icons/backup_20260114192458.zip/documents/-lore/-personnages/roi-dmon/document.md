# Infos
## Individu
- Dénominations : Gadlufer, Empereur du Mal, Roi démon
- Lieu de naissance : à déterminer
- Espèce/ethnie : [[Esprit]],  [[Démons]]
## Social 
- Famille : Amant de [[Crimith]], Père de [[Délith]]
- Amour : Créer 
- Amis : à déterminer
- Autres : 
##  Physique
Possède 42 yeux.
## Objectif
Son seul objectif demeure de créer, son désir de création est inobturable, il se complait uniquement lors de la conception.

## Personnalité 
Obsédé de création, la frustration l'envahit quand il en est incapable, allant jusqu'à le submerger de colère quand il est en manque d'inspiration l'amenant à commettre des actes horribles tel que l'anéantissement des créations qu'il qualifie "d'échec tachant ses chefs d'œuvres" ( [[Page Blanche]]). Cette propension est accentuée par l'inexistence du sentiment de tristesse dans son être étant donné qu'il a extériorisé puis cristallisé afin de pouvoir animer à sa guise ces créations ([[Lacrymète]]).

# Histoire
Le but de son existence fut toujours de créer. Dans cet objectif, il perfectionna ses capacités de [[Extériorisation|cristalisation]] à un stade jamais atteint jusqu'alors par aucun esprit. Cela s'explique par le désintérêt qu'était le réel pour les esprits avant les créations de Gadlufer. C'est ainsi qu'il éleva de la terre de la surface du monde créant les arches, et condensa l'[[Éther|éther]] afin de créer la mer de nuage, façonnant, par la même, son petit monde. [[Mērēli]], loin de la surface de la planète. Bien que la raison de cette volonté de s'éloigner de la surface reste incomprise.

Dans Mērēli, il façonna la matière, la structura, l'imagina afin de former des êtres fonctionnels, capable de se développer et se reproduire, en assez grand nombre d'exemplaires pour créer des espèces. Cependant, malgré ses pouvoirs durement acquis, il resta incapable d'animer ses créations, elles restaient de la matière inerte de toute vie. Frustré par son incapacité à assouvir son désir de création, il se mit à pleurer, ces larmes se cristallisèrent et donnèrent vie à ses créations. Durant 10 longs Velter, il travailla alors à extérioriser sa tristesse et ses larmes afin de créer ce que plus tard on nomma la [[Lacrymète]]. À partir de laquelle il pouvait à sa guise extraire des [[Lacryma et Lacrymiens|lacrymas]], de manière infinie pour donner vie à ses œuvres.

Il créa et créa, maintes espèces, sans jamais discontinuer, durant maints et maints Velters jusqu'à ce qu'un jour, il n'eut plus d'inspiration. Frustré, il s'énerva et jeta de Mērēli les créations qu'il jugea comme ses échecs. Cet évènement fut nommé la [[Page Blanche]]. Reprenant ses esprits, il fut repris d'inspiration, et poursuivit sa frénésie créatrice, jusqu'au jour où il fut défié par un peuple aux cheveux colorés, issus d'une de ses dernières créations, les humains, aidés par d'autres esprits. Ce peuple se révoltait contre lui car lui, leur créateur, était un nuisible et une menace pour eux. En effet sa création incessante de nouvelles créatures était un frein au développement des anciennes qui devaient toujours s'adapter et dans le cas des faibles humains, développer des moyens de survie face à elles. De plus, la menace d'une crise d'inspiration qui pouvait subvenir à tout moment et marquer la fin de leur espèce leur était inconcevable, eux qui se voyaient comme les futurs maîtres de ce monde. Ainsi ils l'avaient affublé du nom de Roi Démon et d'Empereur du mal.

Gadlufer fut [[Extériorisation|cristallisation]], l'affaiblissant, puis son empreinte sur la réalité fut divisée en plusieurs morceaux dans lesquels on le scella. Avant de perdre conscience, il maudit le peuple d'humains qui avait trahit son créateur : 'Du trépas je vous prive, mais du souvenir je vous efface, vous Foïns je vous damne.' Les [[Foïn|Foïns]], peuple condamné à l'immortalité et l'oubli perpétuel, héros du monde privés à jamais de reconnaissance. Les morceaux de Gadlufer désormais qualifiés de [[Relique|Reliques]] furent éparpillés de part le monde, ils passèrent de main en main, de gardien en gardien, de cité en cité, se perdant dans les méandres de l'histoire.


//////

Adorant profondément créer, jamais il ne cessa de concevoir des créatures en tout genre afin de peupler son monde. C'est un manipulateur de matière.
Seulement, les humains voyaient sa création comme nuisible à leur développement, ils l'affublèrent alors du surnom d'Empereur du Mal. Il finirent par réussir à le sceller et éparpillèrent ses morceaux désormais qualifiées de [[Relique|Reliques]] aux quatre coins du monde.
# Annexes
## Divers
L'appellation Empereur du mal provient des humains cherchant à discréditer l'œuvre du Roi Démon.
Le nombre trop conséquent de créations amena à une surpeuplement des archipels pausant des problèmes évidents.

Etapes de création d'êtres :
1. Gadlufer crée des réceptacles, des statues de matière
2. La vie y est insufflée par l'influence de la [[Lacryma et Lacrymiens|lacryma]]
3. 

# Visuels