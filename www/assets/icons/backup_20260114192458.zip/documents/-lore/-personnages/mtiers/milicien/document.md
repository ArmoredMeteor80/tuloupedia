Etre humain maintenant l'autorité du roi du [[Royaume de Nuzam]].
Police médiévale