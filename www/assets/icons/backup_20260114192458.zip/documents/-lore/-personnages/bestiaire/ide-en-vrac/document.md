Sanglicorne  : Une créature mi-sanglier, mi-licorne, dotée d'une corne aiguisée et d'une furie sans égale lorsqu'elle est provoquée.
Hippostriche (Hippopotame + Ostrich) - Un hippopotame avec des pattes longues et rapides comme celles d'une autruche, idéal pour la course.

Licorneige (Licorne + Neige) - Une licorne blanche comme la neige, capable de créer des tempêtes de glace avec sa corne étincelante.

Pingouphante (Pinguin + Éléphant) - Un pingouin géant doté d'une trompe d'éléphant, utilisée pour attraper des poissons dans les eaux profondes.

Chatonard (Chat + Canard) - Un chat au pelage de plumes colorées, avec des pattes palmées pour nager gracieusement.

 Gorilléphant (Gorille + Éléphant) - Un gorille massif avec une trompe d'éléphant, utilisée pour attraper des fruits hors de portée.

Balelou (Baleine + Kangourou) - Une baleine sauteuse capable de bondir hors de l'eau comme un kangourou.

Tigoreille (Tigre + Oreille) - Un tigre doté de grandes oreilles lui permettant de détecter le moindre mouvement à des kilomètres à la ronde.

Écureunard (Écureuil + Canard) - Un écureuil nageur doté d'un bec de canard, capable de plonger profondément pour trouver des trésors sous-marins.

Tiglacier (Tigre + Glacier) - Un tigre recouvert de glace, capable de créer des blizzards avec un simple rugissement.

Tigleu (Tigre + Bleu) - Un tigre bleu vibrant, capable de se fondre dans les profondeurs océaniques pour surprendre ses proies.

Écureuillephant (Écureuil + Éléphant) - Un écureuil géant doté d'une trompe d'éléphant, utilisée pour cueillir des fruits dans les arbres les plus hauts.
Renargile (Renard + Argile) - Un renard dont le pelage est composé d'une substance argileuse, lui permettant de se fondre parfaitement dans son environnement.

Phénisard (Phénix + Lézard) - Un phénix ressuscité sous la forme d'un lézard flamboyant, capable de renaître de ses cendres avec une force renouvelée.

Kangourouille (Kangourou + Grenouille) - Un kangourou doté de pattes palmées et d'une queue puissante, capable de bondir loin dans les marécages.

Tortoraire (Tortue + Volcan) - Une tortue avec une carapace de lave en fusion, capable de résister aux températures extrêmes et de marcher sur les flammes.

Flamandor (Flamant + Condor) - Un flamant géant doté d'une envergure impressionnante, capable de planer pendant des heures à la recherche de proies dans les airs.

Flèchouette (Flèche + Chouette) - Une chouette qui se transforme en flèche une fois lancée, capable de voler rapidement vers sa cible avec une précision mortelle.

Flèchouette (Flèche + Chouette) - Une chouette qui se transforme en flèche une fois lancée, capable de voler rapidement vers sa cible avec une précision mortelle.

Armurielle (Armure + Hirondelle) - Une hirondelle recouverte d'une armure étincelante, capable de voler rapidement et de protéger son porteur des attaques ennemies.

Éclatsang (Éclat + Orang-outan) - Un orang-outan dont les bras sont munis de morceaux de verre tranchants, capable de lacérer ses ennemis avec une force brute.

Renarbre - Un renard habile à se camoufler grâce à son pelage d'argile, se fondant dans les paysages les plus divers.

Fougourou - Un kangourou bondissant dans les fougères, capable de se camoufler parfaitement dans son environnement pour surprendre ses ennemis.

Grocosmos - Une créature cosmique dotée de pouvoirs stellaires, capable de manipuler les astres pour infliger des dommages cataclysmiques.
Nymphlambre - Une nymphe lumineuse qui danse au clair de lune, capable de contrôler les flammes pour créer des illusions et se défendre contre ses ennemis.

Nymphlambre - Une nymphe lumineuse qui danse au clair de lune, capable de contrôler les flammes pour créer des illusions et se défendre contre ses ennemis.
Sérénaphoque - Un phoque angélique doté de pouvoirs de guérison, capable d'apaiser les souffrances et de restaurer la santé de ceux qui l'approchent.

Sylphirafe - Une girafe élancée avec une crinière de feuilles, capable de se fondre dans les arbres et de lancer des rafales de feuilles tranchantes sur ses ennemis.

- Crispétal - Un cristal vivant en forme de pétale, capable de canaliser l'énergie du soleil pour lancer des rayons lumineux dévastateurs sur ses adversaires.
- Rocanin - Un rocher animé par la force de la nature, capable de se transformer en un chien de pierre redoutable, écrasant ses ennemis sous sa masse imposante.
Hurligrane - Un loup hurlant aux pouvoirs de tempête, capable de déclencher des tornades dévastatrices avec ses hurlements lugubres.

Aquarachne - Une araignée aquatique géante, capable de créer des tourbillons sous-marins et d'immobiliser ses proies avec des fils d'eau.

Hydrasil - Un arbre aquatique ancien, capable de contrôler les flux d'eau et de créer des oasis dans les déserts arides.

Candeloup - Un melon qui s'allume comme une bougie lorsqu'on le coupe, apportant une lueur chaleureuse à votre table.

Fourmitraille - Une fourmi géante équipée d'une armure de métal, prête à défendre sa colonie avec une force redoutable.
Lampoule - Une créature lumineuse qui se cache dans les ampoules, apportant de la lumière et de la chaleur à votre maison.
Toupoulpe - Une pieuvre qui se transforme en toupie pour amuser les enfants, tournoyant joyeusement dans les mains des petits.

- Chatapulte - Un chat bondissant comme une catapulte, capable de sauter sur de grandes distances pour attraper ses proies.
- Licorneon - Une licorne lumineuse, capable d'éclairer les chemins sombres avec sa corne étincelante.

Trompéclair - Un éléphant doté d'une trompe électrique, capable de déclencher des éclairs pour se défendre contre les prédateurs.
Armurillon - Un hérisson armé d'épines en acier, capable de se défendre contre les prédateurs avec sa carapace impénétrable.

hibouillanté

Épétingouin - Un pingouin guerrier habile à manier l'épée pour défendre son royaume glacé.

potagerbe
Chocorbeau - Un corbeau malicieux qui se régale de chocolat et qui peut ensorceler les sucreries pour les garder pour lui.

Pingoutils - Un pingouin bricoleur qui utilise ses ailes pour manier des outils ingénieux et résoudre les problèmes les plus complexes.
Sangloquet - Un sanglier qui pleure des larmes de tristesse, capable de guérir les blessures émotionnelles avec son empathie sans faille.


speudo :
lapineige 
champignouf 
ninjdai 