# Inspiration
Lycanthrope + flippant 

# Description
Loups blancs de glaces, chassant en meutes uniquement les soirs de pleines lunes (où son halo blanc assurent leurs camouflages totales dans la brume qu'ils génèrent par cristallisation). 


# gameplay
"froid mordant"