# Inspiration
étymologie du mot "pigeon". 

# Description 

Volatile 

# Domestication

Par leurs caractères dociles, et leurs capacités d'apprentissage de trajet, ils sont utilisés comme messager longues distances. Ils sont très fiables et beaucoup plus rapides que n'importe quel messager terrestre, composant notamment le moyen privilégié d'échange des dirigeants depuis l'empire (notamment entre : Zénith - Aube -Crépuscule). Ils peuvent même mémoriser des circuits relativement long (et non seulement un trajet aller-retour), ce qui s'avère extrêmement pratique. C'est pour eux que les messagers, ainsi que les commères sont communément surnommé "pioupiouteur".  
