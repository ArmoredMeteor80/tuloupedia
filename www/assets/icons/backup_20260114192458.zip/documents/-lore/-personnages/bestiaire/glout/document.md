
# Inspiration
Goutte + gluant 

(féminin Gloutte, hody en langue ancienne)
# Description
Blob, gelée, gluant
