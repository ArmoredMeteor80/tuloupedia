"la complexité de la matière donna la vie, la complexité de l'éther donna les esprits"
