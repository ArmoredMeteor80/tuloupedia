
# Description
Maudits qui reçoivent l'information oublié des [[Foïn|Foïns]] à leurs morts à cause d'un bug dans l'enchantement. 
