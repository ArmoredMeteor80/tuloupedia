# Définition
Êtres reptiliens ailés cracheurs de feu aux dimensions gigantesques. Ils furent la première création de [[Roi Démon|Gadlufer]] réellement doté d'intelligence, notamment ils furent les premier à développer la parole parmi maintes autres choses. S'ils sont aussi orgueilleux et hautain que puissant, ils sont toujours curieux des autres espèces, apprenant notamment leurs langages…  
# Nom
Langue Commune : Dragon
[[Langue Ancienne]] : Witrisha 
