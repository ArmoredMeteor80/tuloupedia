Lutte raciale entre Lutins et Gnomes, les lutins habillés comme le ku klux klan ,ils portent aux gnomes une haine sans raison, ils se munissent de torches. :)

Les deux races sont méchantes de nature, les gnomes sont des gangsters des rues et les lutins des fanatiques à tendance sectaire. Les gnomes utilisent des mots comme hermano et gringo, les lutins sont quant à eux d’extrême droite et plutôt privilégiés. Ils emploient un vocabulaire soutenu.
Tous les gnomes possèdent au moins un bijou.
Il est à noter que les Lutins et Gnomes sont en tout point similaires physiquement, car ceux-ci appartiennent en réalité à la même espèce.
Cette spécificité de l’espèce vise à tourner en dérision le racisme opéré généralement sans raison et illégitimement, simplement conditionnés dès la naissance à haïr autrui, le cycle de la haine.


 Nain : barbus, travailleur 
gnome : chapeaux pointu , flemmard
lutin : , flemmard 

Le Petit Peuple est une seule espèce humanoïde caractérisée par sa petite taille, ses oreilles pointus, son caractère espiègle et son rapport à l'argent. Les hommes ont les oreilles pointés horizontalement tendis que les femmes ont les oreilles pointés verticalement. Il s'agit practiquement de l'unique différence notable entre les individus masculins et féminins, pour cela beaucoup pensent à tord qu'il s'agit d'une espèce monosexué. 

À tendance sectaire, les différents peuples de cette espèce se considèrent comme des espèces totalement différentes malgrès leurs marquantes similarités physiques et culturelles, et se détestent entre elles pour la plus part. Elle se divise en Nains, Lutins, Gnomes, Farfadets, Leprechauns, Brownies, Kobolds et Korrigans.


farfadet : sans chapeau, ni barbe, aux vêtements claires (gris, beige)
leprechauns : chapeau carré + barbe de couleur complémentaire à leurs vêtements
brownies 

Nains : 
signe distinctif : barbus, robustes et trapus, vêtement de travail
Nature : Travailleurs, experts en forge et en minage. 
Habitat : Principalement souterrains, comme des mines ou des cavernes. 
vocabulaire : rapport au travail (expression)
culture : de l'effort, méprises les autres Petit Peuples jugés flemmards, emmagasinant des richesses folles


Gnomes: 
signe distinctif: chapeaux pointus, habits de couleurs ternes (marron notamment), cerni d'un bijoux
Nature : Protecteurs des maisons, espiègles mais bienveillants. 
Habitat : orées villages dans les forêts ou tout lieu proche de la nature. 
vocabulaire : gitant
culture : avoir l'air pauvre pour cacher leurs richesses et éviter d'être volé, détestent Lutins mais vivent dans le même village car leurs richesses met en valeur leurs pauvretés. 

Lutins : 
signe distinctif :  chapeau pointu, habits colorés (vert notamment)
Nature : Malicieux et joueurs, aiment faire des farces. Méprisant envers les pauvres.
Habitat : centre de village
vocabulaire : aristocrate 
culture : exposer richesse, détestent Gnomes mais vivent dans le même village car leurs pauvretés met en valeur leurs richesses. 

Farfadets :
Apparence : vêtements claires (gris, beige), teint brûnatre
Nature : Esprits de la nature, parfois vus comme des protecteurs de la forêt ou des jardins. Habitat : Forêts, jardins, ou tout lieu naturel. 

Leprechauns :
signe distinctif  :  chapeau carré, à la barbe de couleur complémentaire à son vétement
Nature : Connus pour leur ruse, ils cachent leur or au bout d'un arc-en-ciel, solitaires
Habitat : campagne
vocabulaire : argot irlandais 


Kobolds :
signe distinctif : 

korrigan :