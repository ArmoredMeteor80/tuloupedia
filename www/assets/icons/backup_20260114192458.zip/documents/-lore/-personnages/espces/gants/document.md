# Définition
Êtres gigantesques de 10 à 15 mètres à l'apparence primordial, aux formes géométrique rappelant la silhouette humaine. Leur chair est semblable à la terre tout en y étant différent. [[Librē]] est leurs territoires, qu'ils sillonnent toutes leurs vies comme s'ils gardaient la région. 

Quand les Géants sentent la fin de leur vie survenir, ils font un dernier tour de garde avant de se rendre au "Tombeau des Géants" situé quelque part dans les plaines de Librē. Là-bas ils façonnent de la terre (spécial à l'endroit) un corps similaire au leur, puis dans un dernier souffle s'arrachent leur [[Lacryma et Lacrymiens|lacryma]] primordial et l'implante à leur création avant de s'effondrer en mille morceau qui viendront remplacer la terre qu'il vient d'utiliser. 

Ainsi le nombre de Géant sur [[Mērēli]] n'a jamais changé depuis leur création lors de la [[Lagadlyma]]. En effet, nul n'a jamais réussi à tuer un Géant. 


# Noms 
Langue Commune : Géant 
Langue ancienne : Brēin
