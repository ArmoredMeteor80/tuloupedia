
# A
Amyek (am-y-ek) : s'endormir, se fatiguer, coups de barre(avènement de petite énergie)
# B
Brē (bē+rē) : montagne (grande terre)
Brēin (bē+rē+in) : géant (peuple montagne)

# D
Dizu (di-zun) : dimanche (jour des divinités)

# F
Fōzu (fō-zun) : samedi (jour des anciens ou des oubliés)

# H
Hozu (hod-zun) : jeudi (jour de l'eau)
# K
Kexzifkeixsol (ke-xi-zif-ke-ix-sol) : authentification (action de montrer être soit)
# M
Mailam (mail-am) : porte (début frontière) 
Mail (ma-il) : frontière, limite (fin de territoire limité)
Mayek (ma-y-ek) : réveil, repos, café (chute de petite énergie )
Mērēli (mē-rē -li) : Terre (partie céleste) (étendue de nuage et de terre)
Müt (m-üt) : mois (fraction d'itération sous entendu autour du soleil)

# N
Nuzen (nuz+en) : Argent (métal de la lune)
Nuzu (nuz-zun) : lundi (jour de la nuit/lune )

# O
Ōfen (ōf-en) : bibliothèque (information gardé, rangé)
Ōfix (ōf-ix) : confidence (information personnelle)

# R
Rēzu (rē-zun) : vendredi (jour de la terre)
Rif (R-i+f) : griffe

# S
Shazu (sha-zun) : mardi (jour du feu) 
Solen (sol-en) : nom de la monnaie (véritable métal), contractable en "Sol"
Solenzu (sol-en-zun) : mercredi (jour de l'argent, car jour du marché)
Solix (sol-ix) : personnalité (vrai soit)
# T
Tif (T-i+f) : dent 
Tūrin (tūr-in) : selphyde (peuple forêt)

# U
Ütin (üt+in) : Petit Peuple (peuple des semi-hommes)
# W
Wif (Wē+i+f) : aile (vent corps partie
Witrisha (wif+tif+rif-sha) : dragon (aile dent griffe feu)
Wod (wē+hod) : vague (mouvement de l'eau) 

# X
Xzifke (xi-zif-ke) : montrer (autre faire voir)

# Y
Yek (y-ek) : dormir, sommeil, fatigue (petite énergie)

# Z

Zif (Z-i+f) : yeux
Zifke (zif-ke): regarder, voir (action des yeux) 
Zifkexi (zif-ke-xi) : mater, observer, surveiller (regarder autre)
Zunama (zun-ama) : année (soleil itération)
Zunen (zun+en) : Or (métal soleil)
Zyn (zun+ y) : instant (infime soleil)
Zynke (Zyn-ke) : saison (instant d'agir)
