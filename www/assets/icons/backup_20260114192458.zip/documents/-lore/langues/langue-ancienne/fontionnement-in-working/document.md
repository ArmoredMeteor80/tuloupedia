....+ke : action venant de .....
Ke+.... : action de faire 

règles de constructions :
La composition avec une racine "voyelle " (uniquement constitué d'une voyelle) peut amener à un remplacement d'une des voyelles de l'autre racine par la racine voyelle. (ex : zun+y = zyn)

De même la composition de deux racines avec à l'intérieur une même racine "voyelle" vont voir une concaténation des consommes (ex : tif+rif= trif )

Une racine peut être raccourci (perte de consomme final) lors d'une composition tant que le raccourcissement ne transforme la racine en une autre racine (ex : zun=> zu dans les jours de la semaine )

L'inversion des lettres d'une racine à un sens de symétrie (ex : zun et nuz pour jour et nuit) 

