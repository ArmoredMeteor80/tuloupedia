Zun : soleil/jour/lumière    (zu : usé comme "jour" pour  compté les jours)
Nuz : lune/nuit/ombre

---

Mi: moitié/milieu    
Am : début, élévation    
Ma : fin/chute

Ama/m : itération, révolution, tour

---

Di : divin
Nha : démoniaque
In : humain, peuple  -> ni : peu d'humain, village

---


it : île, arche
li : étendue, long 
il : territoire, borné, exïgue
Xi : autre
Ix : soit, personnel 

y : petit
bē : grand, haut, gigantesque 

i- : corps (+f, pour le mot de la partie du corps )

Yē : très nombreux 
üt : bas, sous (fragment aussi)  

---
rē : terre, immobilité
Hod : eau, mouvement A-B, calme
Wē : vent, air, mouvement libre, voyage

Mē : nuage

Sha : chaleur, feu  -> sham : désert, sable
Vo : froid -> Von : glace

Fō : ancien, oublié
ōf : récent, souvenir, information
Sol : Vrai, vérité
Los : faux, mensonge

En : métal, dur, résistant, gardé
Ne : soie, souple

Tū : nature    -> tūr : arbre, forêt

Ek : énergie, magie 
Ke : action, force 




