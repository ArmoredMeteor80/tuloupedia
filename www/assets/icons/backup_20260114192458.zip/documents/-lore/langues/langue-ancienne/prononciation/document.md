Les consommes se prononcent toutes comme en français sauf le "h" qui est fort (comme en allemand). De plus  "sh" se prononce "ch".
Les voyelles se prononcent comme en espagnol ("e" se lit "é", "u" se lit "ou").

Cas particulier : 
z+u : La lettre "z" suivi de la lettre "u" à la fin d'un mot se prononce "s" (ex : les jours de la semaine)