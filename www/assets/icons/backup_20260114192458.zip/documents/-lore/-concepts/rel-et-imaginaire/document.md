"Réel et imaginaire à jamais séparés, pour toujours unis dans l'univers"

Réel et Imaginaire, deux plans d'existences parallèles, subjectifs à l'Observateur (personne qui les qualifie tel quel). 

C'est-à-dire qu'un individu qualifiera de Réel le plan dans lequel il existe, qu'il perçoit naturellement, et l'autre plan comme l'Imaginaire. Pour un individu situé dans l'autre plan d'existence que cet observateur les qualifiatifs sont inversés. Ainsi, dans l'absolu, bien que mystérieuse, la vie et le fonctionnement des [[Esprit|esprits]] ne doit pas être bien différent que celui de la vie normale (matière complexe), avec des besoins de se nourrir, grandir et se reproduire.  