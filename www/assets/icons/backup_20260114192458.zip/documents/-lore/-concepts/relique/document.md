# Définition

**Les reliques constituent l'ensemble des morceaux nécessaires à la restitution du corps du [[Roi Démon]].**
Ces dernières confèrent certains pouvoirs, néanmoins à chaque relique dont le sceau est levé, les monstres se voient octroyé une puissance supérieure du fait que leur créateur imbibe de plus en plus le monde environnant.
# Liste des reliques

- Œil directeur (+ Yeux, qté : 42)
- Cœur
- Estomac
- Poumons
- Sang 
- Langue
- Son âme

