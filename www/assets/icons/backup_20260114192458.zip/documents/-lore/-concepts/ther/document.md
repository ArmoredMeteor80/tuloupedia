" La matière est au réel ce que l'éther est à l'[[Réel et Imaginaire|Imaginaire]]"

Le concept d'éther fait tout aussi référence à la matière de l'Imaginaire et à l'empreinte de celle-ci par la [[Extériorisation|cristallisation]]. 
