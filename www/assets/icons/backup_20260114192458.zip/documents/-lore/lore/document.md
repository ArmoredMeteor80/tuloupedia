> <b><font color="#ff483f">Lore : arrière-plan historique et culturel d'un univers fictionnel</font></b>
