# Monde
[[Mērēli]], Mē-rē-li (nuage-terre-étendue) : étendue de terres et de nuages, il s'agit du nom en Langue Ancienne pour désigner le monde.
# Continent 
##   États
- [[Royaume de Nuzam]]
- [[Royaume d'Amzun]]
- [[Royaume de Zunmi]]
- [[Baronnie du Wēxi ]]
- [[Rifin]]
## Territoires
- [[Librē]]
- [[Terres Selphydes]]
- [[Désert du chien hurlant]]

## Chaînes de montagnes
- [[Monts Ardents]]
-  [[Monts Enubés]]
- [[Les Hautes]]
- [[Brētif]]

##  Espaces d'eau
- [[Mer de Nuages]]
- [[Lac Aure]]
- [[Fissures fluviales]]

## Ruines
- [[Jadis L'Empire Zun|Zénith]]
- [[Royaume Disparu de Misham]] 

# Autre
- [[Yēit-Rif]]

# Visuel 
![[Carte du monde-20240430163128664.webp|571]]