# Caractérisiques
**Nom en langue ancienne :** Yēbrē-Yēvo (yē-brē yē-vo ) : nombreuses montagnes et nombreux froids 
**Instance de :** 
**Capitale :** 
**Régent :** 

**Localisation :** Au Sud-Ouest du Continent  
**Peuples :** 
# Description
Grandes montagnes où se forment les nuages tant l'altitude y est élevée. Il y fait frisquet, dans certaines strates il y neige. Il se trouve là Fōdinah, aussi nommée [[Nuamar]].
# Histoire
