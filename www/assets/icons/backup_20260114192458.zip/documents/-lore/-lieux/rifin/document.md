# Caractérisiques
**Capitale :**  Rifin 
**Régent :** 
**Localisation :** à l'extrême Est du [[Continent]]
**Peuples :** Homme-lézard, humain
**éthymologie  (langue ancienne) :** Rifin (rif-in): Hommes-lézards (Homme griffe)
# Description
# Histoire
