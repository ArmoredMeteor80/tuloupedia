# Caractérisiques
**Capitale :** Zénith (Ruines), 
**Régent :** 
**Localisation :** Situés au centre de l'île Aurore au milieu du [[lac Aure]]
**Peuples :** Fantômes
# Description
# Histoire
[[Division de l'Empire Zun]].