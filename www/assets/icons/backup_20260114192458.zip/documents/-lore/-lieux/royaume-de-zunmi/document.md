# Caractérisiques
**Capitale :** Midi
**Régent :** cadet assassiné
**Localisation  :** au Nord du lac Aure, après la mer de nuage
**Peuples :** humain 
**éthymologie  (langue ancienne) :** Zun-mi : milieu jour, midi 
# Description
# Histoire
[[Division de l'Empire Zun]].