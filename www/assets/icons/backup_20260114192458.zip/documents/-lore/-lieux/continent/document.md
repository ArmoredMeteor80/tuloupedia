Archipe principal : Aussi nommé Grande Arche, il s'agit de l'Arche la plus grande, la plus étendue et peuplé. C'est là où le héros évolue et qu'on retrouve tous les peuples. 

