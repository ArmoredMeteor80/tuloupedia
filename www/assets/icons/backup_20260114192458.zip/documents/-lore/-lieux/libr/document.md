# Caractérisiques
**Instance de :** [[Royaume d'Amzun]]
**Capitale :** 
**Régent :** 
**Peuples :** [[Géants]]
# Description
Vastes plaines où vivent les Géants, elle possède de nombreux pâturages et champs.
# Histoire