# Caractérisiques
**Instance de :** 
**Capitale :** 
**Régent :** 
**Peuples :** 
# Description
Ville cachée dans les [[Monts Enubés]].
# Histoire
**Nom en langue ancienne :** Fōdinah