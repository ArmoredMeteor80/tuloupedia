# Caractérisiques

**Capitale :** Crépuscule
**Régent :** Ainés (jumaux) 
**Localisation :**  à l'Est du lac Aure
**Peuples :** humain
**éthymologie  (langue ancienne) :** Nuz-am : avènement nuit, crépuscule 
# Description
# Histoire
[[Division de l'Empire Zun]].