# Caractérisiques
**Localisation :** à l'Est du [[Royaume de Nuzam]]
**Peuples :** 
**éthymologie :** Brētif (brē-ti+f) : Monts dentés 
# Description
# Histoire
