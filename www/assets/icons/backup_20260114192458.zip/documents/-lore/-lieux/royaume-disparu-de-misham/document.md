# Caractérisiques
**Capitale :** 
**Régent :** 
**Localisation :** milieu du [[Désert du chien hurlant]]
**Peuples :** humain
**éthymologie  (langue ancienne) :** Misham (mi-sham) : Au milieu du désert
# Description
# Histoire
