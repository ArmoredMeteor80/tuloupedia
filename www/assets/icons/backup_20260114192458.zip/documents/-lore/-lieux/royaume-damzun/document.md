# Caractérisiques
**Capitale :** Aube
**Régent :** Ainés (jumeaux)
**Localisation :** à l'Ouest du lac Aure
**Peuples :** humain
**éthymologie  (langue ancienne) :** Am-zun : avènement jour, aube 
# Description
# Histoire
[[Division de l'Empire Zun]].