**Nom en langue ancienne :** Brēsha (brē-sha) : Volcants (montange-feu)
**lieu associé**: Landes draconiques (au pied)
**Capitale :** 
**Régent :** 
**Localisation  :** Au Nord-Ouest du Continent 
**Peuples :** [[dragon]]
# Description

# Histoire
