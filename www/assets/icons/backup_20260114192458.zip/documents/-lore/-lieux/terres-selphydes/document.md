# Caractérisiques

**Nom en langue ancienne :** Ditür (di-tür) : Forêt Divine
**Capitale :** 
**Régent :** 
**Localisation  :** À l'Ouest du Continent au-delà de la rivière 
**Peuples :** [[Selphyde]]
# Description
Forêt vivante, sylvestres protégeant les Selphydes de tout envahisseur.
# Histoire
