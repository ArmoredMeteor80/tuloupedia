# Caractérisiques
**Capitale :** Yēwē (vents nombreux)
**Régent :** Baron de Wēxi
**Localisation :** à l'Est du [[Brētif]]
**Peuples :** humain
**éthymologie  (langue ancienne) :** wēxi : autres vents
# Description
# Histoire
