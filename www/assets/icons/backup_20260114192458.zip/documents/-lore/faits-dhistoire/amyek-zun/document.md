# Définition

Désignation du Velter 843 signifiant littéralement " L'endors du Soleil ", l'un des Velters les plus tragiques de l'histoire du peuple Zun marqué par la mort de l'empereur Zun, la ruine de Zénith et le début de la Guerre Fraternelle.

# Evènements :

07/03/843 - Dizu 5 [[Lumial]] 843 - [[Mort de l'empereur Zun]]