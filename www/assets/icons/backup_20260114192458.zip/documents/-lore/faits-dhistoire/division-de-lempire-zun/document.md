# Description
Cet évènement réfère à la scission opérée il y a une cinquantaine de velters entre les royaumes de :
- [[Royaume d'Amzun]]
- [[Royaume de Zunmi]]
- [[Royaume de Nuzam]]
Leur père le roi de [[Jadis L'Empire Zun]]