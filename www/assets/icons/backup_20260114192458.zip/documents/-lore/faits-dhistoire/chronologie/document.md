# 1 er Éon : 
Velter  0 : [[Lagadlyma]], création des [[Géants]]

Velter 10 : création de la [[Lacrymète]]

 Velter 1  812 : Création des [[dragon|dragons]]

Velter 3 092 : Création des  [[Selphyde|Selphydes]] 


# 2nd Éon :
Velter 4 450 - 0 : [[Page Blanche]]  

Velter 1 271 : création du [[petit peuple]]  

Velter 2 132 : création des [[humain|humains]]

Velter 2 704 : [[relation Humano-Selphyde|Intégration d'un peuple humain par des Selphydes]] 

Velter 2 767 : Naissance de la  [[religions humaines|Première religion]] 

Velter 2 789 : [[histoire de la magie|Développement de la magie]]  

# 3 ième Éon :
Velter 2 936-0 : [[Sceau du Roi Démon|Scellement du Roi Démon]]

## Ère de l'Aure
Velter 753-0 : Fondation de [[Zénith]]
Velter 481 : Naissance du royaume Zun, couronnement...
Velter 800 : Apogé du royaume Zun, naissance de l'Empire Zun
Velter 843 : mort du roi...., division d'empire, début guerre de succession, naissance des royaumes Amzun, Nuzam et Mizun
Velter 893 : trêve ?  fondation du mur ? 


présent :

Velter 894 :

futur :
# 4 ième Éon :
Velter ?-0 : déscellement du Roi Démon, mort/fuite du Roi Démon, chute des arches 








