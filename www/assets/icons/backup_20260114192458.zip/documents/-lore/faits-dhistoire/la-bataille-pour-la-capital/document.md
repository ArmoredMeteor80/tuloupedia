Suite au début de la guerre de succession, héritier A et héritier B sont a la courses pour le trône. Afin de gagner en légitimité et contrôler le centre névralgique de l'empire, héritier A et héritier B font la courses pour la capital. 

Suite à l'arriver d'héritier A, la milice de la capital, ouvre les portes a celui-ci le voyant comme l'héritier légitime de l'empire. Afin d’empêcher successeur A de gagner un avantage considérable(économique, militaire et stratégique), héritier B ordonne un barrage de feu pour brûler la ville. 

La ville brûla pendant 5 jours, ce faisant, l'armée du successeur A ne put rester dans la ville et fut contrainte de sortir par risque d'encerclement, manque de logement et de nourriture qui a brûler dans le dépôt.

Les flammes brûllère les 3/4 de la villes et s'en suivent des milliers de morts brûler vivant dans la tornades de feu.

Assiéger et isolé, la capital ne reçu plus aucun apprivoisement car toute ressources furent réquisitionner par les armées des successeurs. Une famine suivi. A cause de celle-ci, qui affaiblissa la population, une épidémie similaire au cholera se développa et ravagea d'autant plus la population. 

La milice partant avec le successeur A, l'ordre et la sécurité ne sont plus maintenue et avec, le chaos prend bientôt place et une panique général se suis.

Des citadin affamer, brigands et des (pirates/pilleur/viking/nom_de_pirate_lors_accurate) venant de l'extérieur utilise le chaos pour traverser [[Le Levant]] et pille et met a sac la capital durant des jours.

Le restant de la population essaye de fuir la capitale, mais celle-ci prisent entre des champs de batailles, voient plusieurs massacres ce dérouler par les armées pour diverses raison (vole des ressources, suspections d'espionnage par l'ennemie ou bien encore par erreur)

Ainsi la capital se vida de sa population, avec des cadavre jonchant chaque rues, la ville qui autre fois regorgé de vie et d'activité se trouve dans un vide glaçant, le peut qui on survécu on fuit. Tout ce qu'il reste de la glorieuse capital de [[Jadis L'Empire Zun|l'Empire Zun]] n'est que ruines, gravier et cadavres.