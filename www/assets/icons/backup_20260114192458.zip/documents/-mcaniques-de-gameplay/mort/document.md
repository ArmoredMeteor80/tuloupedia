À la mort du Jb, il respon dans à un lieu aléatoire inférieur ou égal son niveau qu’il est déjà visité.

Son souvenir est effacé de tous les autres personnages (pnj), et le joueur perd tout son XP et son stuff non lié, qui est laissé sur son lieu de mort qui despon à la prochaine port du PJ. (voir page dédié au liage)

Attention, l’XP ne sert pas comme ds les autres RPG à augmenter de niveau, plus d'aptitude ect, mais est juste une jauge des souvenirs de son personnage.

Une certaine valeur d'XP sera requise pour diverse action dans le jeux ce qui en fera une ressource importante (elle s'obtient comme l'XP classique ds tt les jeux par contre ).

Pourquoi ? Car le système de niveau hiérarchise beaucoup toutes les élémentsdans les jeux à mon avis, les zones de niveau inférieur à celui d’un joueur sont très vite inutiles diminuant la longévité du jeu et de ses éléments, et l'intérêt de chaque monstre, ressource ect.

Cependant, il est possible de sauvegarder son XP, via le système des Livres et en lisant les objects. En utilisant un Livre, le joueur y enregistre une certaine quantité de son XP en fonction du Livre utilise (cela revient à garder ses souvenirs en les écrivant dans un journal ).

Ces livres doivent cependant être magique et liés pour que les lettres faisant référence à l'oublie ne s’efface pas à sa mort

Fabrication :
=> Ressource : papier de parchemin magique

Utilisation :

=> Encre/pigment magique (extraite de poudres de Runes, les Runes étant une ressource intrinsèque à la magie, il s’agit de magie ‘’cristallisé’’)