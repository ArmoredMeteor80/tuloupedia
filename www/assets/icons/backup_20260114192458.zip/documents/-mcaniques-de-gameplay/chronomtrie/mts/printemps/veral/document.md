[[Müt et Semaine|Müt]]-printemps - éther d'humeur bouillescente
# Caractéristiques

Températures : Douces (entre 10 et 20 C°)
Vent : modérés (brises printanières agréables, vent de printemps amènent averse et dispersent pollen)
Ciel : oscillant entre clair et nuageux 
Humidité : de modérée à élevée
pluies : irrégulières mais fréquentes, modérés 

# Description

Le temps est changeant, mêlant douceur, fraîcheur et variabilité. 

# Effet 

(++) 
 (+) eau, vent
 (=) flammes, foudre, "lumière", métal, ombre, terre,  
 (-)  cendre, glace,
(- -)

