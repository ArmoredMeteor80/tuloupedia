[[Müt et Semaine|Müt]]-été - éther d'humeur némésis 

# Caractéristiques

Températures : douces (15°C-25°C)
Vent : léger ou calme 
Ciel : dégagé, étoilé 
Humidité : modéré (rosée nocturne parfois) voir faible (si sort de Witrishi par ex)
pluies : aucune  

# Description

Müt préféré des astronomes, où on sombre dans une nuit étoilé éternelle. Plus précisément, le soleil ne se lève plus et au mieux parvient à atteindre l'horizon. 
# Effet 

La faune diurne s'adapte soit en se plongeant dans un état d'engourdissement ou de profonde léthargie soit en s'essayant à la vie nocturne. La faune nocturne elle profite pleinement de ce gain d'activité pour se développer et faire notamment des réserves. 
Enfin, le manque de lumière nuit quand à lui au développement des plantes qui voient leurs croissances stagnés reculant le moment des récoltes sans intervention de lumière artificielle. 


(++) ombre
 (+) flammes ,  
 (=) métal, cendre, foudre,  terre, vent,
 (-) eau, glace 
(- -)  "lumière"