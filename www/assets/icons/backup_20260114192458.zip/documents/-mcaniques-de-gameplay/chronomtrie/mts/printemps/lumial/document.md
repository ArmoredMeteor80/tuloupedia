[[Müt et Semaine|Müt]]-printemps - éther d'humeur nitescente 
# Caractéristiques

Températures : basse mais au-dessus de 0°C (surtout les nuits) presque constante
Vent :  léger ou inexistant (< 5km/h)
Ciel : clair 
Humidité : élevée 
pluies : faibles et très courtes mais régulières

# Description

Le temps est plongé dans une sorte de rosée matinale éternel. Et pour cause, ces caractéristiques sont idéales pour le phénomène de rosée (liquéfaction de la vapeur d'eau dans l'air proche du sol). Le ciel sans nuage mêlée aux reflets du soleil dans les gouttes donne une ambiance féerique et agréable par sa fraicheur. 

Ce müt est grandement apprécié par les paysans pour son aspect bénéfiques à la poussé des plantations ainsi que des astronomes pour son ciel particulièrement dégagé, et plus généralement par les amateurs de fraicheurs. 

# Effet 
Favorise la croissance de la flore (abondance d'eau et de lumière), et la faune à sang froid et à mucus externe (ex : Gloute). 

(++) eau, "lumière"
 (+) foudre, glace
 (=)  métal, terre,
 (-)  flammes,  vent
(- -) cendre, ombre,

