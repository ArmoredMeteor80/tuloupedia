[[Müt et Semaine|Müt]]-printemps - éther d'humeur coruscante
# Caractéristiques

Températures : entre 0°C et 10°C rarement plus 
Vent : moyen voir fort 
Ciel : nuageux 
Humidité : élevée 
pluies : Très fortes et quasi perpétuel (mais pas d'orage)

# Description

Des pluies diluviennes tombent toute la durée du müt. Les lacs et les rivières sont pour la plus part en crue, la saison est particulièrement marqué par de nombreuses inondations. 

Pour profiter de la surabondance d'eau, les paysans privilégient lors de cette saison la plantation de plantes à cultures aquatiques (ex : le riz) où la plante est partiellement ou totalement immergé dans l'eau. 

Cette saison est très attendu dans les régions désertiques où elle met souvent fin à des mois de sécheresse, permettant de remplir les points d'eau asséché et que pour quelques semaines le désert reprenne vie.  

# Effet 
Favorise les espèces aquatiques ou amphibies ainsi qu'à mucus externe (ex : Gloute). 

(++) eau, vent
 (+)  foudre, ombre, 
 (=) métal, glace
 (-)  "lumière", terre
 (- -) cendre, flammes