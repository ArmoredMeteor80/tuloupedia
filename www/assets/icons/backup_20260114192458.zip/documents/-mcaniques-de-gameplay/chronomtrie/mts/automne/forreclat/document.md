[[Müt et Semaine|Müt]]-automne - éther d'humeur nitescente 

# Caractéristiques

Températures : varies aux cycles des orages 

avant orage - douces (15-25°C), durant orage - chute de 5°C à 10°C, 
après l'orage - rafraichi (10°C- 20°C ), elles remontent jusqu'à la prochain cycle

Vent : avant et durant orage - violent et irréguliers  (changement de direction et vitesse), après - calme

Ciel : avant l'orage - le ciel se couvre par des nuages de plus en plus épais 
et après l'orage - couverture sporadique avec des périodes de ciel partiellement dégagé 

Humidité : forte
pluies : intenses 

# Description

Müt rythmé par des cycles d'orages électriques. Les cycles sont rapides, de sorte qu'en une journée il y souvent plus d'un orage qui éclate. Durant ces orages la foudre tombe en abondance, ce qui a amené à plusieurs explications mythologiques du phénomène.  

# Effet 

Les vents violents font tomber les feuilles des arbres et la foudre carbonisent plusieurs d'entre eux. La foudre qui tombe avec récurrence sur le sol dans ce müt favorise la croissance de plantes "foudre". La faune aérienne adaptés aux orages s'y développe pleinement ainsi que la faune "foudre". 

(++) foudre,
 (+) eau, vent,  
 (=) flammes, "lumière", ombre
 (-)  cendre, glace, métal, terre,
(- -)  

