[[Müt et Semaine|Müt]]-été - éther d'humeur nitescente 

# Caractéristiques

Températures : douces (15-25°C)
Vent : calme
Ciel : clair avec quelques nuages
Humidité : faible
pluies : faible

# Description

Müt boréal, le soleil ne se couche plus, et ne monte jamais très haut. Il suit une trajectoire basse, semblant tourner autour de l'horizon, cela donne un effet de coucher ou lever de soleil qui dure tout le long du müt. 
# Effet 

La faune nocturne s'adapte en se cachant dans des endroits que les rayons du soleil n'atteignent pas, certain même plonge dans un état d'engourdissement ou de profonde léthargie, ou encore deviennent diurne le temps du müt. Pour la faune diurne, il s'agit souvent d'un müt d'abondance avec une prolifération des ressources disponibles et de leurs heures d'activités. 

(++) "lumière",
 (+) cendre, flammes
 (=) foudre, métal, terre,  vent
 (-) eau, glace
(- -)  ombre

