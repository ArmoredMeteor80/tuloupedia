[[Müt et Semaine|Müt]]-automne - éther d'humeur bouillescente

# Caractéristiques

Températures : agréables (20°C - 30°C) (10°C-15°C la nuit)
Vent : modérés 
Ciel : clair, d'un bleu clair avec quelques nuages blancs et épars 
Humidité : sec
pluies : aucune  

# Description

La chaleur de l'été s'étend plus longtemps et une sécheresse relative frappe le müt. Durant ce müt il est courant que des feux de forêt surviennent, la chaleur estival mêlé à la sécheresse et aux nombreuses feuilles mortes (voir arbres tombés en fonction des müts précédents). 


# Effet 
Les feux participent aux renouvellements des forêts, ont un rôle central dans la reproduction de certains arbres (pyriscence) et marquent la période des bois de charbon (des arbres adaptés aux feux).

(voir écologie du feu wikipédia )


(++) flammes, cendre
 (+)  "lumière",  terre, vent
 (=), métal,  foudre
 (-) ombre, eau
(- -) glace
