[[Müt et Semaine|Müt]]-hiver - éther d'humeur bouillescente

# Caractéristiques

Températures : modérément froides à douces (0°C-10°C)
amplitude thermique faible 
Vent : légers à modérés 
Ciel : alternance ciel clair, ciel couvert (ciel gris)
Humidité : modéré
pluies : légère chutes de neiges (qui fond rapidement) et légères pluies 

# Description

Müt doux, sans neige durable, qualifié de printemps précoce. Il est très espéré car il s'agit du plus agréable des müts d'hiver facilitant la vie quotidienne et les déplacements. Son arrivé en début d'hiver peut aussi signifier un prolongement des activités d'automnes et des campagnes militaires. 
# Effet 


(++)  
 (+) glace
 (=) cendre, eau, foudre, flammes, métal, "lumière",   ombre, vent, terre, 
 (-) 
(- -) 
