[[Müt et Semaine|Müt]]-printemps - éther d'humeur némésis 
# Caractéristiques

Températures : bonnes (15-20°C)
Vent : modérés et  fort 
Ciel : clair 
Humidité : faible (sécheresse)
pluies : faible voir inexistante 

# Description

Le vent souffle fort, dispersant les nuages, empêchant les pluies printanières et amenant la sécheresse. Sécheresse néanmoins agréable par les températures encore fraiches. Ce müt fait craindre des problèmes d'eau en cas d'enchainement avec un Witrisha le même velter qui peut s'avérer catastrophique. Ce müt précipite les départs en campagne militaire, le temps étant idéal (les pluies printanières par la boue qu'elles génèrent peuvent être problématiques en champ de bataille), il est bénéfique d'en profiter le plus longtemps possible. 

# Effet 


(++) vent
 (+) cendre,  "lumière",
 (=) flammes, foudre, métal, terre,
 (-)  ombre, glace
(- -) eau

