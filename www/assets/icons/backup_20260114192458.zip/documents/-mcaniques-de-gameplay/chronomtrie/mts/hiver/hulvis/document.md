[[Müt et Semaine|Müt]]-hiver - éther d'humeur nitescente 

# Caractéristiques

Températures : modérées à froides (-5°C à 5°C)  
(amplitude thermique journalière importante : mâtinés et nuits froides, après-midi douces)
Vent : modérés 
Ciel : alternance ciel clair, ciel couvert (ciel gris)
Humidité : faible voir sec 
pluies : faibles chutes de neige 

# Description

Müt d'hiver modéré avec un froid certain sans être trop rude. Quelques chutes de neige. 

# Effet 


(++) 
 (+)   "lumière", glace
 (=)  cendre, foudre, métal, terre, vent
 (-) , eau, flammes, ombre, 
(- -)  

