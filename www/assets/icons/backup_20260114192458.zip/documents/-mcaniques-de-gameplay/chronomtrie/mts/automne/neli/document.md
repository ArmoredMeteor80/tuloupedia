[[Müt et Semaine|Müt]]-automne - éther d'humeur némésis 
# Caractéristiques

Températures : douces (15°C - 25°C) (5°C-15°C la nuit)  
(amplitude thermique journalière importante : mâtinés fraiches, après-midi chaleureux, et nuits froides )
Vent : modérés à fort 
Ciel : alternance ciel clair, ciel couvert 
Humidité : modéré - élevée 
pluies : averses fréquentes (très courtes et intenses)

# Description

Les arbres se vêtent avec douceur des couleurs automnales, brillant de milles feux. On a le droit à de magnifique coucher de soleil. Il s'agit du müt de prédilection pour la période de la chasse et de la cueillette de champignon. 
# Effet 


(++) 
 (+)  eau, vent
 (=)   foudre, glace, "lumière", métal, ombre, terre, 
 (-) cendre, flammes
(- -)  

