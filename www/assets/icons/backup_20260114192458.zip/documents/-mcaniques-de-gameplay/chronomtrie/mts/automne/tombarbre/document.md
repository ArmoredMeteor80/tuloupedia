[[Müt et Semaine|Müt]]-automne - éther d'humeur coruscante
# Caractéristiques

Températures : avant tempête modérés (10°C-20°C), après tempête - <10°C (remonte jusqu'à prochain cycle)
Vent : avant et durant - violent (70-100km/h, voir 120km/h), direction et changeante, après - calme
Ciel : couvert (nuages denses et épais) 
Humidité : élevée 
pluies : abondantes 

# Description

Müt rythmé par des cycles de tempêtes. Les cycles sont relativement lents, il y a en moyenne une tempête par jour. Des tornades surviennent parfois durant les tempêtes à certains endroits. Par précotions les ailes des moulins sont rempliés (même s'il est courant que des paysans orgueilleux et confiants prennent le risque de les garder dans l'espoir de tourner à plein régime quand les autres sont arrêtés). 

Ce müt est particulièrement craint dans les régions désertiques par les tempêtes de sables qu'il engendre. 
# Effet 
Les vents puissants déracines les vieux arbres, contribuant ainsi au renouvellement des forêts. 
La faune adapté au tempête en profite. 

(++)  vent
 (+)  eau, ombre, 
 (=) foudre, flammes, glace, métal,  terre
 (-)  "lumière", cendre, 
 (- -) 