[[Müt et Semaine|Müt]]-été - éther d'humeur coruscante 

# Caractéristiques

Températures : agréables (20°C - 30°C) (10°C-15°C la nuit) 
Vent : brise légère, rythmé par de temps en temps des vents forts  
Ciel : clair, d'un bleu profond avec quelques nuages blancs et épars 
Humidité : modérément humide, réduisant sensation chaleur (par peu sans sec)
pluies : aucune or un ou deux jours où il y a des averses passagères ou des orages  

# Description

Dit müt de l'aventure, il possède les caractéristiques idéales pour voyager. Son arrivé est d'ailleurs souvent un signe de repartir pour les aventuriers, voyageurs et commerçants itinérants, voir de vacances (pour les nobles). Il s'agit aussi d'un excellent müt pour la navigation, le vent étant idéal pour pousser les voiles couplé à un mer de nuages calmes. 
# Effet 


(++) 
 (+) cendre, flammes, "lumière",  vent, foudre
 (=), métal, terre, eau
 (-) cendre, glace,
(- -)  

