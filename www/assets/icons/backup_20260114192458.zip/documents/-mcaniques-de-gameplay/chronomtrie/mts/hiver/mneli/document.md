[[Müt et Semaine|Müt]]-hiver - éther d'humeur némésis 
# Caractéristiques

Températures : basse  à froides (proches de 0°C voir un peu en dessous )
Vent :  léger ou inexistant (< 5km/h)
Ciel : couvert, grises et sombres 
Humidité : élevée 
pluies : faibles voir nul 

# Description

Le temps est plongé dans le brouillard éternel. Et pour cause, ces caractéristiques sont idéales pour le phénomène la formation de brouillard  (liquéfaction en hauteur de la vapeur d'eau dans l'air ). Le monde couvert de brouillard donne une ambiance de mystère. Ce müt pose des problèmes de déplacements notamment en cité. Le manque de visibilité est parfois dangereux. 

# Effet 
Les prédateurs des grands froids, se camouflant dans le brouillard, envahissent les grands espaces, allant jusqu'à aller dans les cités. 
(++)  
 (+) eau, glace, ombre,
 (=) foudre, "lumière", métal, terre,
 (-)  cendre, flammes,  vent
(- -)  
