[[Müt et Semaine|Müt]]-hiver - éther d'humeur coruscante

# Caractéristiques

Températures : très froides (-5°C à -15°C voir moins) (-20°C à -30°C la nuit)
Vent : fort, glacial (augmentant le ressenti du froid)
Ciel : couvert (gris)
Humidité : fortes 
pluies : fortes chutes de neige (tempête de neiges fréquentes, neige poudreuse qui s'acccumule)

# Description

Müt glacial caractérisé par des tempêtes de neiges fréquentes. Il s'agit d'un müt très dures où la majorité des personnes restent enfermé dans les foyers. Les routes sont bloqués par la neige, et les voies principales doivent être déneigés. 

# Effet 
La flore résistance au froid s'étend, et la faune s'adapte aux conditions rigoureuses (hivernation, long poil). 

(++)  glace
 (+)   ombre, vent, eau
 (=)   cendre,  métal, terre, 
 (-)   foudre,  "lumière"
(- -)  flammes

