[[Müt et Semaine|Müt]]-été - éther d'humeur bouillescente

# Caractéristiques

Températures : intenses (30°C - 40°C voir plus), nuit au-dessus de 20°C 
Vent : soit inexistant soit très chaud (vend du sud) 
Ciel : clair, d'un bleu profond avec quelques nuages blancs et épars 
Humidité : modérément humide, réduisant sensation chaleur, voir sec sans que ce soit désagréable
pluies : aucune  

# Description

Müt de sécheresse et de canicule, il s'agit d'un des müts les plus crains surtout quand il se réitère plusieurs fois impliquant des restrictions d'eau, des problèmes de récoltes et des incendies. La chaleur pesante rend le travail difficile. L'arrivé de ce müt est souvent aussi une raison de trêve de guerre de la même manière que l'hiver, sa chaleur rendant infernal le port d'armure et l'effort physique à l'extérieur. 
# Effet 
Les plantes et les arbres subissent un stress hydrique important entraînant un jaunissement ou une perte prématurée des feuilles. La faune à sang froid et à mucus externe se retrouve en difficulté pour survivre. 

(++) flammes
 (+) cendre, "lumière",  terre
 (=), métal,  foudre, vent
 (-) ombre
(- -)  eau, glace

