
On compte 4 saisons : printemps, été, automne, hiver
Chaque saison dure 3 [[Müt et Semaine|müts]], équivalent IG et IRL à 6 semaines pour l'automne et l'hiver, et 7 pour le printemps et l'été (le dernier de printemps et le premier d'été durant 1 semaine de plus).


# Printemps



description :

impact mapping :
impact Bestiaire :
impact ressource génération :

fêtes :



# Été 

# Automne 


# Hiver
