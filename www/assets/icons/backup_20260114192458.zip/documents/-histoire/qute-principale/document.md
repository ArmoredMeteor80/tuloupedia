# Synopsis

**Synopsis : Notre [[Héros|héros]] se réveille amnésique dans un monde dont il ignore tout. Il prend connaissance au fur et à mesure de sa quête et la nature  de son but.  En effet, ce-dernier est sous le joug d'une malédiction. Afin de la briser il lui faut ressusciter le [[Roi Démon]] et mettre un terme à son existence (End game : devenir mortel ). Pour accomplir le Rite de Renaissance, une condition sine qua non est de mise : réunir tous les membres du corps du démon appelées [[Relique|Reliques]] :**
# Prologue (Chapitre 0)

## I - L'éveil
Le joueur s'éveille au milieu de la forêt, amnésique. Une jeune fille Lutine qui cueillait des fruits conduit le héros jusqu'au village Lutin. Plus précisément jusqu'aux [[Milicien | miliciens]]. 

Annexes : [[001 - Remerciement de la gnome]] 
# Chapitre 1